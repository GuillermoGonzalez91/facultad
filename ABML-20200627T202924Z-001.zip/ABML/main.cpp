#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <windows.h>// PARA UTILIZAR VARIOS COMANDOS DE WINDOWS
// Solo las teclas i k para arrib y abajo

#define ARRIBA 'i'
#define ABAJO 'k'
#define ENTER 13

using namespace std;
#include "fecha.h"
#include "prototipos.h"
#include "tipos.h"
#include "posicionador.h"
#include "alumno_metodos.h"
#include "alumnos.h"
#include "profesores_metodos.h"
#include "profesores.h"

#include "menu.h"

int main()

{
   menu_principal();

   return 0;
}


