#ifndef PROTOTIPOS_H_INCLUDED
#define PROTOTIPOS_H_INCLUDED
        // MENU PRINCIPAL
/*********************************************************************/
void alta_profesor();
void baja_profesor();
void modificar_profesor();
void listado_profesor();
/*********************************************************************/
void alta_alumno();
void baja_alumno();
void modificar_alumno();
void listado_alumno();
/*********************************************************************/
void menu_profesores();
void menu_alumnos();
void menu_deportes();
void menu_division();
/*********************************************************************/


void alta_deporte();
void baja_deporte();
void modificar_deporte();
void listado_deporte();
/*********************************************************************/
int menu(const char titulo[], const char *opciones[], int n); // FUNCION QUE LLAMA AL CURSOR
void menu_principal();
/*********************************************************************/
/*********************************************************************/
/*********************************************************************/
/*********************************************************************/
/*********************************************************************/
/*********************************************************************/

#endif // PROTOTIPOS_H_INCLUDED
